/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 16, 2008
 * Time: 5:58:30 PM
 * To change this template use File | Settings | File Templates.
 */
class DenemeController {
    def show = {
        println grailsApplication;
        render(text:"sezgin1");
    }
}