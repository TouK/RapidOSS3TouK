package test;
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 17, 2008
 * Time: 3:31:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestCase {
    String name;
    Test test;
}
