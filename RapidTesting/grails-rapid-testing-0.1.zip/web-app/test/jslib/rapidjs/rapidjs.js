YAHOO.namespace('rapidjs');
YAHOO.namespace('rapidjs.data');
YAHOO.namespace('rapidjs.component');
YAHOO.namespace('rapidjs.admin');
YAHOO.namespace('rapidjs.riadmin');
YAHOO.namespace('rapidjs.provisioner');
YAHOO.namespace('rapidjs.component.windows');
YAHOO.namespace('rapidjs.component.dialogs');
YAHOO.namespace('rapidjs.component.tree');
YAHOO.namespace('rapidjs.component.map');
YAHOO.namespace('rapidjs.component.menu');
YAHOO.namespace('rapidjs.component.layout');
YAHOO.namespace('rapidjs.component.grid');
YAHOO.namespace('rapidjs.component.autocomplete');
YAHOO.namespace('rapidjs.component.crud');
YAHOO.namespace('rapidjs.component.list');
YAHOO.namespace('rapidjs.component.rc');

