package com.ifountain.testing
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: Jun 19, 2008
 * Time: 4:57:16 PM
 * To change this template use File | Settings | File Templates.
 */
class TestLock {
    public static boolean isTestRunning = false;
}